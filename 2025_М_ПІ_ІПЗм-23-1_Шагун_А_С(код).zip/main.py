# fake_news_detector.py

import pandas as pd
import numpy as np
import re
import nltk
import spacy
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

# Підготовка ресурсів
nltk.download('stopwords')
from nltk.corpus import stopwords
stop_words = set(stopwords.words('english'))
nlp = spacy.load("en_core_web_sm")

# Очищення тексту
def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z\s]", "", text)
    return text

# Лематизація
def lemmatize_text(text):
    doc = nlp(text)
    tokens = [token.lemma_ for token in doc if token.lemma_ not in stop_words and token.is_alpha]
    return " ".join(tokens)

# Повна передобробка одного тексту
def preprocess_text(text):
    cleaned = clean_text(text)
    lemmatized = lemmatize_text(cleaned)
    return lemmatized

# Передобробка всіх текстів (без паралельності)
def preprocess_dataframe(df, text_column="text"):
    df[text_column] = df[text_column].apply(preprocess_text)
    return df

# Основна функція

def main():
    # Завантаження даних
    true_news = pd.read_csv("data/True.csv")
    fake_news = pd.read_csv("data/Fake.csv")

    true_news['label'] = 0
    fake_news['label'] = 1

    # Вибираємо маленьку підмножину для швидкої перевірки
    # true_news_sample = true_news.sample(n=5, random_state=42)
    # fake_news_sample = fake_news.sample(n=5, random_state=42)

    data = pd.concat([true_news, fake_news], axis=0)
    data = data[['title', 'text', 'label']]
    data['text'] = data['title'] + " " + data['text']
    data = data[['text', 'label']]

    print("Передобробка текстів...")
    data = preprocess_dataframe(data, text_column="text")

    X_train, X_test, y_train, y_test = train_test_split(
        data['text'], data['label'], test_size=0.2, random_state=42)

    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    model = LogisticRegression(max_iter=1000)
    model.fit(X_train_tfidf, y_train)

    y_pred = model.predict(X_test_tfidf)

    print("Результати класифікації:")
    print(classification_report(y_test, y_pred))

if __name__ == "__main__":
    main()
