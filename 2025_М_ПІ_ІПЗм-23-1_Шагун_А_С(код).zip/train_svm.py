import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import os

from preprocess import preprocess_dataframe

# Візуалізація матриці помилок
def plot_confusion_matrix(y_true, y_pred, save_path=None):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(5,4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["Real", "Fake"], yticklabels=["Real", "Fake"])
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.title('Confusion Matrix (SVM)')
    if save_path:
        plt.savefig(save_path)
        print(f"Матрицю збережено в {save_path}")
    plt.show()

def main():
    # Завантаження даних
    true_news = pd.read_csv("data/True.csv")
    fake_news = pd.read_csv("data/Fake.csv")

    true_news['label'] = 0
    fake_news['label'] = 1

    data = pd.concat([true_news, fake_news], axis=0)
    data = data[['title', 'text', 'label']]
    data['text'] = data['title'] + " " + data['text']
    data = data[['text', 'label']]

    print("Передобробка текстів...")
    data = preprocess_dataframe(data, text_column="text")

    X_train, X_test, y_train, y_test = train_test_split(
        data['text'], data['label'], test_size=0.2, random_state=42)

    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    model = SVC(probability=True)
    model.fit(X_train_tfidf, y_train)

    y_pred = model.predict(X_test_tfidf)

    print("Результати класифікації (SVM):")
    print(classification_report(y_test, y_pred))

    os.makedirs("models", exist_ok=True)
    plot_confusion_matrix(y_test, y_pred, save_path="models/confusion_matrix_svm.png")

    joblib.dump(model, "models/fake_news_model_svm.pkl")
    joblib.dump(vectorizer, "models/tfidf_vectorizer_svm.pkl")
    print("Модель SVM, векторизатор та графік збережено!")

if __name__ == "__main__":
    main()
