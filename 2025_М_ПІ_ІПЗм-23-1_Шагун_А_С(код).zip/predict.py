import joblib
from preprocess import preprocess_text


class FakeNewsClassifier:
    def __init__(self, model_path, vectorizer_path):
        self.model = joblib.load(model_path)
        self.vectorizer = joblib.load(vectorizer_path)
        print("Модель та векторизатор успішно завантажено!")

    def predict(self, text):
        processed_text = preprocess_text(text)
        vectorized_text = self.vectorizer.transform([processed_text])
        prediction = self.model.predict(vectorized_text)
        prediction_proba = self.model.predict_proba(vectorized_text)

        label = "Fake" if prediction[0] == 1 else "Real"
        probability = prediction_proba[0][prediction[0]]

        print(f"Результат: {label} ({probability * 100:.2f}% впевненість)")
        return label, probability


if __name__ == "__main__":
    print("Виберіть модель для перевірки:")
    print("1 - LogisticRegression")
    print("2 - SVM")
    print("3 - XGBoost")
    choice = input("Ваш вибір: ")

    if choice == "1":
        model_path = "models/fake_news_model.pkl"
        vectorizer_path = "models/tfidf_vectorizer.pkl"
    elif choice == "2":
        model_path = "models/fake_news_model_svm.pkl"
        vectorizer_path = "models/tfidf_vectorizer_svm.pkl"
    elif choice == "3":
        model_path = "models/fake_news_model_xgboost.pkl"
        vectorizer_path = "models/tfidf_vectorizer_xgboost.pkl"
    else:
        print("Неправильний вибір!")
        exit()

    classifier = FakeNewsClassifier(model_path, vectorizer_path)

    while True:
        print("\nВведіть текст новини (в кінці введіть END на окремому рядку):")
        lines = []
        while True:
            line = input()
            if line.strip() == "END":
                break
            lines.append(line)
        text = "\n".join(lines)
        if text.strip().lower() == "exit":
            break
        classifier.predict(text)
