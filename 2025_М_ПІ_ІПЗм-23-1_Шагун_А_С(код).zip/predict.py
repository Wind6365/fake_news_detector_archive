import joblib
from preprocess import preprocess_text


class FakeNewsClassifier:
    def __init__(self, model_path, vectorizer_path):
        self.load_model(model_path, vectorizer_path)

    def load_model(self, model_path, vectorizer_path):
        self.model = joblib.load(model_path)
        self.vectorizer = joblib.load(vectorizer_path)
        print("Модель та векторизатор успішно завантажено!")

    def predict(self, text):
        processed_text = preprocess_text(text)
        vectorized_text = self.vectorizer.transform([processed_text])
        prediction = self.model.predict(vectorized_text)
        prediction_proba = self.model.predict_proba(vectorized_text)

        label = "Fake" if prediction[0] == 1 else "Real"
        probability = prediction_proba[0][prediction[0]]

        print(f"Результат: {label} ({probability * 100:.2f}% впевненість)")
        return label, probability


def select_model(classifier):
    print("\nДоступні моделі:")
    print("1 - LogisticRegression")
    print("2 - SVM")
    print("3 - XGBoost")
    choice = input("Ваш вибір: ")

    if choice == "1":
        model_path = "models/fake_news_model.pkl"
        vectorizer_path = "models/tfidf_vectorizer.pkl"
    elif choice == "2":
        model_path = "models/fake_news_model_svm.pkl"
        vectorizer_path = "models/tfidf_vectorizer_svm.pkl"
    elif choice == "3":
        model_path = "models/fake_news_model_xgboost.pkl"
        vectorizer_path = "models/tfidf_vectorizer_xgboost.pkl"
    else:
        print("Неправильний вибір!")
        return
    classifier.load_model(model_path, vectorizer_path)


if __name__ == "__main__":
    classifier = FakeNewsClassifier("models/fake_news_model.pkl", "models/tfidf_vectorizer.pkl")

    while True:
        print("\nВведіть текст новини (в кінці введіть END на окремому рядку):")
        print("Або введіть 'model' щоб змінити модель, або 'exit' щоб завершити програму.")
        lines = []
        while True:
            line = input()
            if line.strip().lower() == "exit":
                exit()
            elif line.strip().lower() == "model":
                select_model(classifier)
                break
            elif line.strip() == "END":
                break
            lines.append(line)

        if lines:
            text = "\n".join(lines)
            classifier.predict(text)
