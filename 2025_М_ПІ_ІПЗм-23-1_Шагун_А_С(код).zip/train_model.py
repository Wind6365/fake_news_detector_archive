# train_model.py (оновлена версія з автоматичним збереженням графіка)

import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import os

from preprocess import preprocess_dataframe


# Візуалізація матриці помилок
def plot_confusion_matrix(y_true, y_pred, save_path=None):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["Real", "Fake"], yticklabels=["Real", "Fake"])
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.title('Confusion Matrix')
    if save_path:
        plt.savefig(save_path)
        print(f"Матрицю збережено в {save_path}")
    plt.show()


def main():
    # Завантаження даних
    true_news = pd.read_csv("data/True.csv")
    fake_news = pd.read_csv("data/Fake.csv")

    true_news['label'] = 0
    fake_news['label'] = 1

    data = pd.concat([true_news, fake_news], axis=0)
    data = data[['title', 'text', 'label']]
    data['text'] = data['title'] + " " + data['text']
    data = data[['text', 'label']]

    print("Передобробка текстів...")
    data = preprocess_dataframe(data, text_column="text")

    X_train, X_test, y_train, y_test = train_test_split(
        data['text'], data['label'], test_size=0.2, random_state=42)

    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    model = LogisticRegression(max_iter=1000)
    model.fit(X_train_tfidf, y_train)

    y_pred = model.predict(X_test_tfidf)

    print("Результати класифікації:")
    print(classification_report(y_test, y_pred))

    # Переконуємось, що існує директорія для моделей
    os.makedirs("models", exist_ok=True)

    # Збереження матриці помилок у файл
    plot_confusion_matrix(y_test, y_pred, save_path="models/confusion_matrix.png")

    # Збереження моделі та векторизатора
    joblib.dump(model, "models/fake_news_model.pkl")
    joblib.dump(vectorizer, "models/tfidf_vectorizer.pkl")
    print("Модель, векторизатор та графік збережено!")


if __name__ == "__main__":
    main()
